package org.projectlombok.test;

/**
 * Hello world!
 */
public final class App {
    public static void main (final String[] args) {
        System.out.println("Hello World!");
    }
}
