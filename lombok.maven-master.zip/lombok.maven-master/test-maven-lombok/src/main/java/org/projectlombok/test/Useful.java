package org.projectlombok.test;

/**
 * A useful interface
 */
public interface Useful {
    void doSomething ();
}

